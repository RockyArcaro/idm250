<footer style="background-color:black; color:white;"> 
    &copy; 2024 | IDM 250
    <?php wp_footer() ?>
</footer>

</body>

</html>