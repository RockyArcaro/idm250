<div class="post-align" data-component="content">
  <?php echo get_the_content(); ?>
</div>