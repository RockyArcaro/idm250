<?php
/*
Template Name: Graphics Post Template
*/
get_header(); // Include header template

<h1>
    <?php echo get_the_title(); ?>

get_footer(); // Include footer template
?>